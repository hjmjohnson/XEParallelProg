#include <memory.h>
#include <stdio.h>
#include "Sudoku.h"
#include "Print.h"

int gNumCalls = 0;  

PUZZLE Puzzles[NUM_NODES];
void SetCellToZero(SUDOKU *pPuzzle, NODE &Node,int Idx)
{
	// make a copy of the first cell, and clear contents in puzzle
	Node = pPuzzle->Nodes[Idx];
	pPuzzle->Nodes[Idx].number = 0;
	
	#ifdef USE_SSE
	SSEClearValue(Node.number,Idx,pPuzzle);
	#endif

	pPuzzle->Nodes[Idx].TempCellsLeft= REMOVED_CLUE;
}
void RestoreCellValue(SUDOKU *pPuzzle, int Idx, NODE &Node)
{
	// restore Node
	#ifdef FIX_DATARACE_2yy
	#pragma omp critical
	#endif
	{
	pPuzzle->Nodes[Idx] = Node;
	}

	#ifdef USE_SSE
	SSESetValue(Node.number,Idx,pPuzzle);
	#endif
}
// -------------------------------------
//
//	
//
// -------------------------------------
void GenDoWork(PUZZLE *pPuzzle, int Idx)
{
	int NumRecursions = 0;

	NODE Node1;
	NODE Node2;
	SetCellToZero(&pPuzzle->MinusOne, Node1, Idx );
	
	// -2
	// start from where i left off to find the next clue we can replace
	// but don't traverse beyond end f the array :-)

	#ifdef USE_PARALLEL_TASK_2
	#pragma omp parallel 
	#endif
	{
	  #ifdef USE_PARALLEL_TASK_2
	  #pragma omp single nowait
	  #endif
	  {
	for(int j = Idx + 1 ; j < NUM_NODES; j++ )
	{		
		if(pPuzzle->MinusOne.Nodes[j].number > 0)
		{
		
			// create a copy of the n-1, and place in the n-2 
			memcpy(&pPuzzle->MinusTwos[j],&pPuzzle->MinusOne,sizeof(SUDOKU));

			#ifdef USE_PARALLEL_TASK_2
			// create the tasks
			#pragma omp task firstprivate(j) private(Node2)
			#endif
			{
			SetCellToZero(&pPuzzle->MinusTwos[j], Node2, j); 
			
			// AT this moment we have cleared the two original clues
			// and stored their values in Node1 and Node2

			// Now traverse through the puzzle adding one new
			for(int k = 0; k < NUM_NODES; k++)
			{
				// the new number
				for(int num1 = 1 ; num1 <= MAX_NUM; num1++)
				{
					if( pPuzzle->MinusTwos[j].Nodes[k].number ==0 
						&& OKtoAddClue(&pPuzzle->MinusTwos[j], k,num1))
					{
						
						#ifdef FIX_DATARACE_2yy
						#pragma omp critical
						#endif
						{
							// set the new value
							pPuzzle->MinusTwos[j].Nodes[k].TempCellsLeft = ADDED_CELL;
							pPuzzle->MinusTwos[j].Nodes[k].number = num1;
						}

						#ifdef USE_SSE
						SSESetValue(num1,k,&pPuzzle->MinusTwos[j]);
						#endif
		
						#ifdef PRINT_CLUES
						PrintClues(pPuzzle->MinusTwos[j]);
						#endif
						Solve(&pPuzzle->MinusTwos[j],0,0, NumRecursions);

						#ifdef FIX_DATARACE
						#pragma omp atomic
						#endif			
						gNumCalls++;
		
						// restore the cell to hold its original (zero)
						#ifdef FIX_DATARACE_2yy
						#pragma omp critical
						#endif
						{
							pPuzzle->MinusTwos[j].Nodes[k].number = 0;
							pPuzzle->MinusTwos[j].Nodes[k].TempCellsLeft = FULL_CELL; //line prob redundant
						}

						#ifdef USE_SSE
						SSEClearValue(num1,k,&pPuzzle->MinusTwos[j]);
						#endif
					}						
				}				
				
				// and now restore the second clue we removed
				RestoreCellValue(&pPuzzle->MinusTwos[j], j, Node2);
				
			}	
		  }
		}
	  }
	} // end #pragma omp single
  } // end pragma omp parallel
  RestoreCellValue(&pPuzzle->MinusOne, Idx, Node1);

}
// -------------------------------------
//
//	main
//
// -------------------------------------
int Generate(SUDOKU *pPuzzle)
{

	//pPuzzle is the original puzzle - which should never get altered.

	PrintClues(pPuzzle);

	// for every node in the original tree, we travese the puzzle
	// removing one solution at a time in an attempt to find a new puzzle

	// do the -2 + 1 search

	#ifdef USE_PARALLEL_TASK
	#pragma omp parallel 
	#endif
	{
	  #ifdef USE_PARALLEL_TASK
	  #pragma omp single nowait
	  #endif
	  {

	// we only iterate to -1, because DoWork looks at i + 1
	for(int i = 0 ; i < NUM_NODES -1; i++ )
	{
		// -1	
		NODE Node1 = pPuzzle->Nodes[i];
		if(Node1.number > 0)
		{
			// create a copy of the top level node;
			memcpy(&Puzzles[i].MinusOne,pPuzzle,sizeof(SUDOKU));

			#ifdef USE_PARALLEL_TASK
			#pragma omp task firstprivate(i)
			#endif
			GenDoWork(&Puzzles[i],i);
		}
	  }
	} // end omp single nowait
} // end #pragma onp parallel
	return gNumCalls;
}