#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <memory.h>
#include <string.h>
#include "Sudoku.h"

// with 2 solutons  100000005000030000002040000000000000034000700000206001200005000070000030000001000
//					183967425469532817752148693621473589534819762897256341216385974975624138348791256
//					193867425468532917752149683621473598534918762987256341216395874875624139349781256

// from http://www.sudokuwiki.org/sudoku.htm
// easiest: 000105000140000670080002400063070010900000003010090520007200080026000035000409000
//			672145398145983672389762451263574819958621743714398526597236184426817935831459267

// gentle:	000004028406000005100030600000301000087000140000709000002010003900000507670400000
//			735164928426978315198532674249381756387256149561749832852617493914823567673495281

// moderate:400010000000309040070005009000060021004070600190050000900400070030608000000030006
//			459716382612389745873245169387964521524173698196852437965421873731698254248537916

// Tough:	309000400200709000087000000750060230600904008028050041000000590000106007006000104
//			369218475215749863487635912754861239631924758928357641173482596542196387896573124


//Diabolical: 000704005020010070000080002090006250600070008053200010400090000030060090200407000
//			  981724365324615879765983142197836254642571938853249716476398521538162497219457683
			 

int FillPuzzle(char Line[], SUDOKU * pPuzzle, char *Name)
{
	int NumClues = 0;
	size_t Length = strlen(Line);

	for(unsigned int i = 0; i < NUM_NODES;i++)
	{

		if (i < Length)
		{
			pPuzzle->Nodes[i].number = Line[i]-48;
		}
		else
		{
			pPuzzle->Nodes[i].number = 0;
		}
		
		pPuzzle->Nodes[i].cell =i;
		
		if(pPuzzle->Nodes[i].number > 0)
		{
			pPuzzle->Nodes[i].TempCellsLeft = PRED_CELL;
			pPuzzle->Nodes[i].OriginalClue = true;
			NumClues++;
		}
		else
		{
			pPuzzle->Nodes[i].TempCellsLeft = FULL_CELL;
			pPuzzle->Nodes[i].OriginalClue = false;
		}

	}
	if(Length < NUM_NODES)
		printf("WARNING: There are not enough clues (%d) in %s\n",Length,Name);

	if(Length > NUM_NODES)
		printf("WARNING: There are too many clues (%d)  in %s\n",Length, Name);

	return NumClues;

}


int LoadFile(char * Name, SUDOKU * pPuzzle)
{

	FILE * hFile;
	char Line[82];
	int NumClues = 0;
	
	hFile = fopen( Name, "r");
	if (hFile == NULL)
	{
		printf("ERROR: Failed to open \"%s\"\n", Name);
		return 0;
	}
	else
	{
		size_t NumChars; 
		//do{	
			memset(Line,'\0',sizeof(Line));
			NumChars = fread(Line,sizeof(char),81,hFile);
			
			//if(!feof(hFile))
			{
				printf("%s\n",Line);
				NumClues = FillPuzzle(Line,pPuzzle,Name);
			}
		//} while (NumChars > 0);

		// Process & close file
		fclose(hFile);
	}

	return NumClues;
}