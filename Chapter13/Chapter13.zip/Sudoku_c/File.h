#pragma once
int LoadFile(char * Name, SUDOKU * pPuzzle);