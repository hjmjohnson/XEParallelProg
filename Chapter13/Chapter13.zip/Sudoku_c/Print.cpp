#include "Sudoku.h"
#include <stdio.h>
#include <windows.h>


static HANDLE Console;
static int X;
static int Y;

// -------------------------------------
//
//	
//
// -------------------------------------
void DisplayInit()
{
	Console=GetStdHandle(STD_OUTPUT_HANDLE);
}


// -------------------------------------
//
//	
//
// -------------------------------------
void GoToXY(int X, int Y)
{
  COORD Coordinates = {X, Y};
  SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),Coordinates);
}


// -------------------------------------
//
//	
//
// -------------------------------------
void PrintNode(NODE Node, bool bJustClues)
{
	int IdxRow = Node.cell / MAX_NUM; 
	int IdxCol = Node.cell % MAX_NUM; 
	int Colour = 0;
	int Number = Node.number;

	// insert spaces
	IdxRow += IdxRow/BASE;
	IdxCol += IdxCol/BASE;

	// preassigned are marked bright \light blue
	if(Node.TempCellsLeft == PRED_CELL)
	{
		Colour =  FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_INTENSITY;
	}
#if 0
	else if(Node.TempCellsLeft == ADDED_CELL)
	{
		Colour =  FOREGROUND_RED | FOREGROUND_INTENSITY;
	}
	else if(Node.TempCellsLeft == REMOVED_CLUE)
	{
		Colour = 0x07 | FOREGROUND_INTENSITY;
	}
#else
	else if(Node.OriginalClue)
	{
		Colour =  FOREGROUND_RED | FOREGROUND_INTENSITY;
	}
#endif
	else
	{
		Colour =  0x07;
	}

	SetConsoleTextAttribute(Console, Colour );

	if(bJustClues && !(
		Node.TempCellsLeft == ADDED_CELL ||
		Node.TempCellsLeft == PRED_CELL
		))
	{
		Number = 0;
	}
	// GoToXY(IdxCol , IdxRow);
	printf("%d",Number);

	Colour =  0x07;
	SetConsoleTextAttribute(Console, Colour );

}




// -------------------------------------
//
//	
//
// -------------------------------------
void PrintPuzzle(SUDOKU *pPuzzle, bool bJustClues,bool bWrap,bool bDoubleSpace)
{
	// printf("SOLVED [%d]:",PuzzleIdx);
	// for every node
	for(int i = 0 ; i < NUM_NODES; i++ )
	{
		PrintNode(pPuzzle->Nodes[i],bJustClues);
		if(!((i+1)%BASE))
		{

			if(bWrap)
			{

				if(!((i+1)% (BASE * BASE)))
				{
					printf("\n");
					if(!((i+1)% (BASE * BASE * BASE)))
					{
						printf("\n");
					}
				}
				else
				{
					printf(" ");
				}
			}
			else
			{
				printf(" ");
			}
		}
	}
	
	printf("\n");
	if (bDoubleSpace)
		printf("\n");

}

// -------------------------------------
//
//	
//
// -------------------------------------
void PrintClues(SUDOKU *pPuzzle)
{
	PrintPuzzle(pPuzzle, true,true,true);
}


// -------------------------------------
//
//	
//
// -------------------------------------
void PrintPuzzle(SUDOKU *pPuzzle)
{
	PrintPuzzle(pPuzzle, false,true,true);
}

// -------------------------------------
//
//	
//
// -------------------------------------
void PrintPuzzleNoWrap(SUDOKU *pPuzzle)
{
	PrintPuzzle(pPuzzle, false,false,false);
}
