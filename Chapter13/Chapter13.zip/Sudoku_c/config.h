
#pragma once

#define BASE 3
// #define BASE 2
#define USE_HASH_MAP_FOR_RESULTS


// Un-optimised Solver
// run in RELEASE build
#ifdef STEP_1
#define JUST_SOLVER
#define PRINT_PUZZLE
#endif

// Solver with SSE intrinsics
// run in RELEASE build
#ifdef STEP_2
#define JUST_SOLVER
#define PRINT_PUZZLE
#define USE_SSE
#endif

// Building generator
// run in RELEASE build
#ifdef STEP_3
#define USE_SSE
#endif


// adding OpenMP tasks to generator
// run in RELEASE build
#ifdef STEP_4
#define USE_SSE
#define USE_PARALLEL_TASK
#ifndef __INTEL_COMPILER
#error "You must use the Intel Compiler to build this step.
#endif
#endif

// checking for data races
// run in DEBUG build
#ifdef STEP_5
#undef BASE
#define BASE 2
#define USE_SSE
#define USE_PARALLEL_TASK
#ifndef __INTEL_COMPILER
#error "You must use the Intel Compiler to build this step.
#endif
#endif


// fixing data races
// run in DEBUG build
#ifdef STEP_6
#undef BASE
#define BASE 2
#define USE_SSE
#define USE_PARALLEL_TASK
#define FIX_DATARACE
#ifndef __INTEL_COMPILER
#error "You must use the Intel Compiler to build this step.
#endif
#endif


// Checking Concurrency
// run in RELEASE build
#ifdef STEP_7
#define USE_SSE
#define USE_PARALLEL_TASK
#define FIX_DATARACE
#ifndef __INTEL_COMPILER
#error "You must use the Intel Compiler to build this step.
#endif
#endif

// Checking Concurrency after removing an ill placed critical section
// run in RELEASE build
#ifdef STEP_8
#define USE_SSE
#define USE_PARALLEL_TASK
#define FIX_DATARACE
#define REMOVE_CRITICAL
#ifndef __INTEL_COMPILER
#error "You must use the Intel Compiler to build this step.
#endif
#endif

////  NOTE - The Case Study ends at STEP_8! ////////////
/*
    The following additional steps are provided for you to investigate further.
*/


// Adding fine-grained parallelism
// run in RELEASE build
#ifdef STEP_9
#define USE_SSE
#define USE_PARALLEL_TASK_2
#define FIX_DATARACE
#ifndef __INTEL_COMPILER
#error "You must use the Intel Compiler to build this step.
#endif
#endif

// CheckData races
// run in DEBUG build
#ifdef STEP_9
#undef BASE
#define BASE 2
#define USE_SSE
#define USE_PARALLEL_TASK_2
#define FIX_DATARACE
#ifndef __INTEL_COMPILER
#error "You must use the Intel Compiler to build this step.
#endif
#endif


// Fix Data races
// run in DEBUG build
#ifdef STEP_10
#undef BASE
#define BASE 2
#define USE_SSE
#define USE_PARALLEL_TASK_2
#define FIX_DATARACE
#define FIX_DATARACE_2
#ifndef __INTEL_COMPILER
#error "You must use the Intel Compiler to build this step.
#endif
#endif

// Check Concurency 
// run in RELEASE build
#ifdef STEP_11
#define USE_SSE
#define USE_PARALLEL_TASK_2
#define FIX_DATARACE
#define FIX_DATARACE_2
#ifndef __INTEL_COMPILER
#error "You must use the Intel Compiler to build this step.
#endif
#endif

// list of all defines
// #define JUST_SOLVER
// #define USE_SSE
// #define USE_PARALLEL_TASK
// #define FIX_DATARACE
// #define PRINT_PUZZLE
// #define PRINT_CLUES
// #define BASE 2
