#pragma once

void DisplayInit();
void GoToXY(int X, int Y);
void PrintNode(NODE Node);
void PrintPuzzle(SUDOKU *pPuzzle);
void PrintClues(SUDOKU *pPuzzle);
void PrintPuzzleNoWrap(SUDOKU *pPuzzle);

