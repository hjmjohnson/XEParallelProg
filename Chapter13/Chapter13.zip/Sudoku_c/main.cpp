#include <stdlib.h>
#include <memory.h>
#include <stdio.h>
#include <time.h>
#include <list>
#include "Sudoku.h"
#include "Print.h"
#include "File.h"
#include "config.h"
#include <omp.h>
#include <map>


int gNumSolutions = 0;
// omp_lock_t ompLock;
using namespace std;

// pointer to hold unique solutions
typedef list<SUDOKU *> PuzzleList;
typedef pair <std::string, SUDOKU *> Pair;

#ifdef USE_HASH_MAP_FOR_RESULTS

// struct Compare  {  bool operator()(const char * a , const char * b)   {  return std::strcmp(a, b) < 0;  }  };  

typedef std::map<std::string, SUDOKU *> HashMap; 


HashMap gResults;
#else
PuzzleList gResults;
#endif


// ------------  START SSE -------------
#ifdef  USE_SSE

__m128i BinBox[MAX_NUM];
__m128i BinRow[MAX_NUM];
__m128i BinColumn[MAX_NUM];


// -------------------------------------
//
//	
//
// -------------------------------------
void SSESetValue(int Number, int Idx, SUDOKU *pPuzzle)
{
	// create a bit pattern to represent the node index
	int i0 = 0;
	int i1 = 0;
	int i2 = 0;
	int i3 = 0;
	if(Idx > 63)
		i2 = 1 << (Idx % 64);
	else if (Idx > 31)
		i1 = 1 << (Idx % 32);
	else
		i0 = 1 << Idx;

	__m128i Value =_mm_set_epi32(i3,i2,i1,i0);
	#if defined(FIX_DATARACE) && !defined(REMOVE_CRITICAL) 
	#pragma omp critical
	#endif
	{
	pPuzzle->BinNum[Number - 1] = _mm_or_si128(pPuzzle->BinNum[Number - 1],Value);
	}

}


// -------------------------------------
//
//	
//
// -------------------------------------
void SSEClearValue(int Number, int Idx, SUDOKU *pPuzzle)
{
	// create a bit pattern to represent the node index
	int i0 = 0;
	int i1 = 0;
	int i2 = 0;
	int i3 = 0;
	if(Idx > 63)
		i2 = 1 << (Idx % 64);
	else if (Idx > 31)
		i1 = 1 << (Idx % 32);
	else
		i0 = 1 << Idx;

	__m128i Value =_mm_set_epi32(i3,i2,i1,i0);

#ifdef FIX_DATARACE_2x
#pragma omp critical
#endif
	{
		pPuzzle->BinNum[Number - 1] = _mm_andnot_si128(Value,pPuzzle->BinNum[Number - 1]);

	}
}

// -------------------------------------
//
//	
//
// -------------------------------------
/* 
*/
void FillSSEMasks()
{

// bit masks for  BinRow[0]
/* Each bit of the regsister represents a position on the puzzle
   Each layer of the array represents a mask for Rows.  So Row 0 can be found by 
   ANDING BinRow[0]  with a resister of values. 


BinRow[0] = Bits 0 to 8
BinRow[1] = Bits 9 to 9
*/

	// col & row patterns
	__m128i RotatingBit = _mm_set_epi32(0,0,0,1);
	int loopcnt = 0;
	for(int i = 0; i < MAX_NUM ; i++)
	{
		for (int j = 0 ; j < MAX_NUM; j++)
		{
			// BinRow[i] |= 1 << i;
			BinRow[i]= _mm_or_si128(BinRow[i], RotatingBit);
			BinColumn[j]=  _mm_or_si128(BinColumn[j], RotatingBit);

			// Box calc
			int k = ((i / BASE)*BASE )+ (j / BASE);
			BinBox[k] = _mm_or_si128(BinBox[k], RotatingBit);

			// rotate the bit
			RotatingBit =  _mm_slli_epi64(RotatingBit, 1);
			loopcnt++;
			if(loopcnt == 64)
				RotatingBit = _mm_set_epi32(0,1,0,0);
		}
	}
}

// -------------------------------------
//
//	
//
// -------------------------------------
int FillSSEStructures(SUDOKU *pPuzzle)
{
	int NumClues = 0;

	memset(pPuzzle->BinNum,'\0',sizeof(__m128i) * MAX_NUM);

	FillSSEMasks();

	// for every node
	for(int i = 0 ; i < NUM_NODES; i++ )
	{
		int Number = pPuzzle->Nodes[i].number;
		if(Number == 0)
			continue;
		SSESetValue(Number, i,pPuzzle);
		NumClues++;
	}	
	return NumClues;
}

#endif
// ------------  END SSE -------------


// -------------------------------------
//
//	
//
// -------------------------------------
void StoreResult(SUDOKU *pPuzzle)
{
	SUDOKU * pCopy = (SUDOKU*) malloc(sizeof(SUDOKU));
	memcpy(pCopy,pPuzzle,sizeof(SUDOKU));


	  
#ifdef USE_HASH_MAP_FOR_RESULTS
	gResults.insert(Pair(pPuzzle->String,pCopy));
//	printf("Storing: ");
//	PrintPuzzleNoWrap(pPuzzle);
#else
	gResults.push_back(pCopy);
#endif
}


// -------------------------------------
//
//	
//
// -------------------------------------
bool StoreSolution(SUDOKU * pPuzzle, int PuzzleIdx)
{

	char Key [NUM_NODES + 1];
	
	// build up the key
	int i;
	for (i = 0; i < NUM_NODES; i++)
	{
		Key[i] = pPuzzle->Nodes[i].number + '1' -1;
	}	
	Key[i] = '\0';
	pPuzzle->String = Key;
	// if results list is empty just add it
	if(gResults.empty())
	{
		StoreResult(pPuzzle);
		return true;
	}

	#ifdef USE_HASH_MAP_FOR_RESULTS
	
	// if key has no been used
	HashMap::iterator ci = gResults.find(pPuzzle->String);
	if( ci == gResults.end())
	{
		StoreResult(pPuzzle);
		return true;
	}

	return false;


	#else

	//traverse each puzzle - we must go through every one, to see if the new one is unique
	for (PuzzleList::const_iterator ci = gResults.begin(); ci != gResults.end(); ++ci)
	{
		SUDOKU * pPuzzleIt = *ci;

		// assume it's already duplicated	
		bool bAlreadyExists = true;

		// check if unique
		// first time it finds a puzzle with mismatching nodes, 
		// then the 
		for (int i = 0; i < NUM_NODES; i++)
		{
			if (pPuzzle->Nodes[i].number != pPuzzleIt->Nodes[i].number)
			{
				bAlreadyExists = false;
			}
		}	
		// if on this iteration we didn't find a unique puzzle
		// then the puzzle already exists, so return false
		// NB: we return true when the puzzle is unique
		if (bAlreadyExists)
		{
			return false;
		}
	}

	StoreResult(pPuzzle);

	return true;
	#endif
}



// -------------------------------------
//
//	
//
// -------------------------------------
void PrintAllPuzzles()
{
	int i = 0;

	#ifdef USE_HASH_MAP_FOR_RESULTS 
	//traverse each puzzle - we must go through every one, to see if the new one is unique
	for(HashMap::iterator ci=gResults.begin(); ci!=gResults.end(); ++ci)  
	{
		SUDOKU * pPuzzleIt = (*ci).second;

	#else
	for (PuzzleList::const_iterator ci = gResults.begin(); ci != gResults.end(); ++ci)
	{
		SUDOKU * pPuzzleIt = *ci;
	#endif
		i++;

		printf("%4d: ",i);
		PrintPuzzleNoWrap(pPuzzleIt);
	}
}

// -------------------------------------
//
//	
//
// -------------------------------------
bool NumInRow(SUDOKU * pPuzzle, int Idx, int Num)
{

	int IdxRow = Idx / MAX_NUM; 
	for (int i = 0; i < NUM_NODES; i++)
	{
		// don't test self with self!
		if(Idx == i)
				continue;
		int Row = i /MAX_NUM;
		if(Row == IdxRow && pPuzzle->Nodes[i].number == Num)
			return true;	
	}
	return false;
}

// -------------------------------------
//
//	
//
// -------------------------------------
bool NumInColumn(SUDOKU * pPuzzle, int Idx, int Num)
{
	int IdxCol = Idx % MAX_NUM; 

	for (int i = 0; i < NUM_NODES; i++)
	{
		// don't test self with self!
		if(Idx == i)
			continue;
		int Col = i % MAX_NUM;

		if(Col == IdxCol && pPuzzle->Nodes[i].number == Num)
			return true;	
	}
	return false;
}


// -------------------------------------
//
//	
//
// -------------------------------------
bool NumInSquare(SUDOKU * pPuzzle, int Idx, int Num)
{

	int IdxRow = Idx / MAX_NUM; 
	int IdxCol = Idx % MAX_NUM; 

	
	// reset to start of row s
	int RowStart = ((IdxRow) / BASE) * BASE  ;
	int ColStart = ((IdxCol) / BASE )* BASE ;

	// reset to start of column
	for (int i = 0; i < BASE; i++)
	{
		for ( int j = 0; j < BASE; j++)
		{
			
			int TmpIdx =  (RowStart * MAX_NUM)  + (i * MAX_NUM)  + ColStart + j;

			// don't test self with self!
			if(TmpIdx != Idx)
			{
				if(pPuzzle->Nodes[TmpIdx].number == Num)
				{
					return true;
				}
			}
		}
	}
	return false;
}


// -------------------------------------
//
//	
//
// -------------------------------------
bool SSEHasNumber(SUDOKU *pPuzzle,__m128i BinArray[], int i, int j)
{
	// rows
	__m128i Tmp1 = ( _mm_and_si128(pPuzzle->BinNum[j-1], BinArray[i]));
	__m128i Tmp2 = _mm_setzero_si128();
	
	// this returns 0xfffffffffffff... if they are equal
	Tmp2 = _mm_cmpeq_epi32(Tmp2, Tmp1);

	unsigned int p[4];
	_mm_storeu_si128((__m128i *)p, Tmp2);
	
	if (p[0] == 0 ||
		p[1] == 0 ||
		p[2] == 0)
		return true;

	return false;
}


// -------------------------------------
//
//	
//
// -------------------------------------
bool NumberInRow(SUDOKU *pPuzzle,int IdxNode, int IdxRow, int Num)
{
#ifdef  USE_SSE
	return SSEHasNumber(pPuzzle,BinRow, IdxRow, Num);
#else
	return NumInRow(pPuzzle,IdxNode,Num);
#endif
	
}

// -------------------------------------
//
//	
//
// -------------------------------------
bool NumberInColumn(SUDOKU *pPuzzle,int IdxNode, int IdxCol, int Num)
{
#ifdef  USE_SSE
	return SSEHasNumber(pPuzzle,BinColumn, IdxCol, Num);
#else
	return NumInColumn(pPuzzle,IdxNode,Num);
#endif
	
}

// -------------------------------------
//
//	
//
// -------------------------------------
bool NumberInSquare(SUDOKU *pPuzzle,int IdxNode, int IdxBox, int Num)
	{
#ifdef  USE_SSE
	return SSEHasNumber(pPuzzle,BinBox, IdxBox, Num);
#else
	return NumInSquare(pPuzzle,IdxNode,Num);
#endif
	

}


// -------------------------------------
//
//	
//
// -------------------------------------
bool DoWork(SUDOKU * pPuzzle,int RowIdx)	
{


	int IdxBase = (RowIdx * MAX_NUM);
	int IdxLimit = IdxBase + MAX_NUM;

for(int Idx = IdxBase; Idx < IdxLimit; Idx++)
//for(int Idx = NodeIdx; Idx < IdxLimit; Idx++)
{
	int IdxRow = Idx / MAX_NUM; 
	int IdxCol = Idx % MAX_NUM; 
	int IdxBox = ((IdxRow/BASE)* BASE) + (IdxCol/BASE);
	
	// if the cell has a value, just skip to the next
	#ifdef FIX_DATARACE_2x
	int Num;
	#pragma omp critical
	Num = pPuzzle->Nodes[Idx].number;
	if(Num == 0)
	#else
	if(pPuzzle->Nodes[Idx].number == 0)
	#endif
	{				
		// reset to full amount
		pPuzzle->Nodes[Idx].TempCellsLeft = FULL_CELL;

		// populate with all posibilites
		for (int Num = 1 ; Num <= MAX_NUM; Num++)
		{
			// rows
			if (NumberInRow(pPuzzle, Idx, IdxRow, Num))
			{
				RemoveNum(pPuzzle->Nodes[Idx].TempCellsLeft,Num);
			}
							
			// columns
			else if (NumberInColumn(pPuzzle, Idx, IdxCol, Num))
			{
				RemoveNum(pPuzzle->Nodes[Idx].TempCellsLeft,Num);
			}

			// squares
			else if(NumberInSquare(pPuzzle, Idx, IdxBox, Num))
			{
				RemoveNum(pPuzzle->Nodes[Idx].TempCellsLeft,Num);
			}
		
			// if TempCellsLeft is zero, means puzzle is invalid
			if(pPuzzle->Nodes[Idx].TempCellsLeft == 0)
				return false;

		} // end for (int j = 1 ; j <= MAX_NUM; j++)
	} // end if(pPuzzle->Nodes[i].number == 0)

}
	return true;
}

// -------------------------------------
//
//	
//
// -------------------------------------
bool FillPossibilities(SUDOKU * pPuzzle, int NodeIdx)
{
	bool bReturn = true;

	{
		{
			int RowIdx = NodeIdx / MAX_NUM;

			// for every node
			for(int i = RowIdx ; i < MAX_NUM; i++ )
			{	
				// if(pPuzzle->Nodes[i].TempCellsLeft =! 0)
				if(bReturn != false)
				{
					{
						if (!DoWork(pPuzzle,i))
								bReturn = false;
					}
				}
			} 
		} 
	}  
 
	return bReturn;
}

// -------------------------------------
//
//	
//
// -------------------------------------
bool Allowed(SUDOKU *pPuzzle,int NodeIdx,int Number)
{
	return ContainsNum(pPuzzle->Nodes[NodeIdx].TempCellsLeft,Number)?true:false;
}


// -------------------------------------
//
//	
//
// -------------------------------------
int GetNextIdx(SUDOKU *pPuzzle, int NodeIdx)
{
	int j;
	for (j = NodeIdx; j < NUM_NODES;j++)
	{
		if(pPuzzle->Nodes[j].number == 0)
			break;
	}
	return j;
}


// -------------------------------------
//
//	
//
// -------------------------------------
void StoreNumber(SUDOKU *pPuzzle, int NodeIdx, NODE &BackupNode, int Nesting, int i)
{
	// store value in node
	BackupNode = pPuzzle->Nodes[NodeIdx];
			
	pPuzzle->Nodes[NodeIdx].number = i;
	#ifdef  USE_SSE
		SSESetValue(i, NodeIdx, pPuzzle);
	#endif
	if (Nesting == 1)
		pPuzzle->Nodes[NodeIdx].TempCellsLeft = ADDED_CELL;
}

// -------------------------------------
//
//	
//
// -------------------------------------
void ClearNumber(SUDOKU *pPuzzle, int NodeIdx, NODE &BackupNode, int i)
{
	pPuzzle->Nodes[NodeIdx]= BackupNode;

	#ifdef  USE_SSE
	SSEClearValue(i, NodeIdx, pPuzzle);
	#endif
}



// -------------------------------------
//
//	
//
// -------------------------------------
bool Solve(SUDOKU *pPuzzle, int PuzzleIdx, int NodeIdx, int & NumRecursions)
{
	#ifdef FIX_DATARACE_2
	#pragma omp atomic
	#endif
	NumRecursions ++;
	bool res;
	
	if (NodeIdx >= NUM_NODES)
	{
		// StoreSolution returns true is solutionis unique
		#ifdef FIX_DATARACE
		#pragma omp critical
	//	omp_set_lock(&ompLock);
		#endif
		{
			res = StoreSolution(pPuzzle,PuzzleIdx);
		}
		#ifdef FIX_DATARACE
	//	omp_unset_lock(&ompLock);
		#endif
	

		if (res)
		{
			//printf("%2d",PuzzleIdx);
			//printf("%2d ",omp_get_thread_num());
			#ifdef FIX_DATARACE
			#pragma omp atomic
			#endif
			gNumSolutions++;
			#ifdef PRINT_PUZZLE
			#ifdef FIX_DATARACE_2x
			#pragma omp critical
			#endif
				PrintPuzzle(pPuzzle);
			#endif
		}
		return true;
	
	}	

	if(!FillPossibilities(pPuzzle,NodeIdx))
		return false;

	NODE BackupNode;
	for(int i=1; i<=MAX_NUM; i++)
	{
		if(Allowed(pPuzzle,NodeIdx,i))
		{
			StoreNumber(pPuzzle,NodeIdx,BackupNode,NumRecursions,i);
			int NewIdx = GetNextIdx(pPuzzle, NodeIdx);
		
			// if the solve failed, restore prev value
			if (!Solve(pPuzzle,PuzzleIdx,NewIdx,NumRecursions))
			{
				ClearNumber(pPuzzle,NodeIdx,BackupNode,i);
			}
		}
	}
	return false;

}

// -------------------------------------
//
//	
//
// -------------------------------------
int InitPuzzle(int argc, char* argv[],SUDOKU * pPuzzle)
{
	int NumClues = 0;
	if (argc < 2)
	{
		printf("You must enter a filename\n");
		return 0;
	}

	NumClues = LoadFile(argv[1],pPuzzle);

	#ifdef  USE_SSE
if(NumClues > 0)
		FillSSEStructures(pPuzzle);
	#endif

	return NumClues;
}

// -------------------------------------
//
//	main
//
// -------------------------------------
int main(int argc, char* argv[])
{
	int NumRecursions = 0;
	int NumClues = 0;
	SUDOKU Puzzle;
	DisplayInit();
	clock_t start, stop;

//	omp_init_lock(&ompLock);

	printf("%s\n",
	#ifdef STEP_1
		"STEP_1"
	#endif
	
	#ifdef STEP_2
		"STEP_2"
	#endif

	#ifdef STEP_3
		"STEP_3"
	#endif

	#ifdef STEP_4
		"STEP_4"
	#endif

	#ifdef STEP_5
		"STEP_5"
	#endif

	#ifdef STEP_6
		"STEP_6"
	#endif

	#ifdef STEP_7
		"STEP_7"
	#endif

	#ifdef STEP_8
		"STEP_8"
	#endif

	#ifdef STEP_9
		"STEP_9"
	#endif

	#ifdef STEP_10
		"STEP_10"
	#endif

	#ifdef STEP_11
		"STEP_11"
	#endif

	#ifdef STEP_12
		"STEP_12"
	#endif
		);
		
		printf("Running %s %s version %s Parallelism using the %s compiler \n",
		#ifdef _DEBUG
			"DEBUG",
		#else
			"RELEASE",
		#endif

		#ifdef USE_SSE
			"SSE",
		#else
			"NON-SSE",
		#endif
		#if defined(USE_PARALLEL_TASK) || defined(USE_PARALLEL_TASK_2)
			#ifdef USE_PARALLEL_TASK
				"WITH COURSE GRAINED",
			#else
				"WITH FINE GRAINED",
			#endif
		#else
			"WITHOUT",
		#endif

		#ifdef __INTEL_COMPILER
			"INTEL"
		#else
			"MICROSOFT"
		#endif
	);


	start = clock();
	
	NumClues = InitPuzzle(argc,argv, &Puzzle);
	if( NumClues > 0)
	{
#ifdef  JUST_SOLVER
		PrintClues(&Puzzle);
		Solve(&Puzzle,0,0, NumRecursions);
		int NumCallsToSolver = 1;
#else
		int NumCallsToSolver = Generate(&Puzzle);
#endif

		stop = clock();

		// PrintAllPuzzles();

		double Time = (double)((stop - start)/1000.0);

		printf("%d clue puzzle:  Called solver %d times, Found %d solution(s) in %-5.4f seconds\n",
			NumClues, NumCallsToSolver,gNumSolutions,Time);
	}

}



bool OKtoAddClue(SUDOKU * pPuzzle, int Idx, int Num)
{
	int IdxRow = Idx / MAX_NUM; 
	int IdxCol = Idx % MAX_NUM; 
	int IdxBox = ((IdxRow/BASE)* BASE) + (IdxCol/BASE);
	
	if (NumberInRow(pPuzzle, Idx, IdxRow, Num)		||
		NumberInColumn(pPuzzle, Idx, IdxCol, Num)	||
		NumberInSquare(pPuzzle, Idx, IdxBox, Num))
	{
		return false;
	}
return true;
}