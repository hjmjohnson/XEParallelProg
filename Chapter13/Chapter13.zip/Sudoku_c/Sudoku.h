#pragma once
#include <emmintrin.h>
#include "config.h"
#include <string>


// bitmap for 
#define NumToBitMap(x) 1 << (x-1)
#define AddNum(var,num) var = var | (NumToBitMap(num))
#define RemoveNum(var,num) var = var & ~(NumToBitMap(num))
#define ContainsNum(var,num) (NumToBitMap(num)) & var


#define IDX_INVALID -1
#define PRED_CELL 0xDEF
#define ADDED_CELL 0xAAA
#define REMOVED_CLUE 0xEEEE



#define MAX_NUM (BASE * BASE) 
#define NUM_NODES (MAX_NUM * MAX_NUM)

#if (BASE == 2)
#define PUZZLE DEV2_4
#define FULL_CELL 0xF
#else
// #define PUZZLE PUZZLE_39_1
// #define PUZZLE PUZZLE_VERY_EASY_1
// #define PUZZLE PUZZLE_CHALLENGING_1
// #define PUZZLE DUP_1
#define PUZZLE DUP_2
#define FULL_CELL 0x1FF
#endif



typedef struct NODE
{
	int cell;
	int number;
	int TempCellsLeft;
	bool OriginalClue;

}_NODE;


typedef struct SUDOKU
{
	NODE Nodes[NUM_NODES];
	__m128i BinNum[MAX_NUM];
	std::string String;

}_SUDOKU;

typedef struct PUZZLE
{
	SUDOKU MinusOne;
	SUDOKU MinusTwos[NUM_NODES];
}_PUZZLE;



// prototypes
int GetNextIdx(SUDOKU *pPuzzle, int NodeIdx);
bool Solve(SUDOKU *pPuzzle, int PuzzleIdx, int NodeIdx, int & NumRecursions);
int Generate(SUDOKU *pPuzzle);
void StoreNumber(SUDOKU *pPuzzle, int NodeIdx, NODE &BackupNode, int Nesting, int i);
void ClearNumber(SUDOKU *pPuzzle, int NodeIdx, NODE &BackupNode, int i);
bool OKtoAddClue(SUDOKU * pPuzzle, int Idx, int Num);

#ifdef USE_SSE
void SSESetValue(int Number, int Idx, SUDOKU *pPuzzle);
void SSEClearValue(int Number, int Idx, SUDOKU *pPuzzle);
#endif

