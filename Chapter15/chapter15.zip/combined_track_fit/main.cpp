/**************************************************************************
 * CERN, GSI Darmstadt                                                    *
 * All rights reserved.                                                   *
 *                                                                        *
 * Permission to use, copy, modify and distribute this software and its   *
 * documentation strictly for non-commercial purposes is hereby granted   *
 * without fee, provided that the above copyright notice appears in all   *
 * copies and that both the copyright notice and this permission notice   *
 * appear in the supporting documentation. The authors make no claims     *
 * about the suitability of this software for any purpose. It is          *
 * provided "as is" without express or implied warranty.                  *
 **************************************************************************/

#include <iostream>  // for output messages
#include <limits>    // for data limits
#include "arbb.hpp"    // to access the ArBB libraries
#include "fit_util.h"    // a set of constants

#define DELTA 1.E-1    // Define an accuraccy limit

#undef max      // undefine the max and min set up within windows
#undef min      // so that standard max and min can be used

typedef float ftype;    // set ftype to be single precision data

using namespace std;

// ------------------------- Protypes
void readInput( int * nT, int * nS);
void fitTracks( ftype (*T)[6], ftype (*C)[15], int nT, int nS );
void fitTracksArBB( ftype (*T)[6], ftype (*C)[15], int nT, int nS );

// ******************************************************************
int main(int /*argc*/, char* /*argv*/[])
{
    int i, nT, nS;  // loop conter, number of tracks & stations
	double Timing, ArBBTiming;  // Timing values

// -------------------------------------------------------------------
    try
	{
//                           Read data from magnetic and track files
//                           Also sets up dynamic arrays whos pointers
//                           are loaded into the class pointer data
        readInput( &nT, &nS );
//                           Set up pointer arrays for serial parameters
//                           For each track set up array for State matrix
//                             T1[6] = x, y, tx, ty, qp, z
        ftype (*T1)[6]  = new ftype[nT][6];
//                            For each track set up array for Covariance matrix C1[15]
		ftype (*C1)[15] = new ftype[nT][15];
//                           Set up pointer arrays for ArBB parallel parameters
        ftype (*T2)[6]  = new ftype[nT][6];
		ftype (*C2)[15] = new ftype[nT][15];

// ------------------------- Run Serial version
//                           Set Timing to maximum value for a double
        Timing = std::numeric_limits<double>::max();
//                           Repaet NUM_RUNS times (5 times)
        for(i=0; i<NUM_RUNS;i++)
		{
			// create time variable
            double time;
            {
				// start ArBB scoped timer which will measure
				// time within its scoped lifetime
                const arbb::scoped_timer timer(time);
				// call main parallel track fitting function
				fitTracks( T1, C1, nT, nS );
            }
			// scoped time ends here, var time holds its value
			// reset Timing to minimum time so far
            Timing = std::min(Timing, time);
        }

// ------------------------- Run Parallel ArBB version
//                           Set Timing to maximum value for a double
        ArBBTiming = std::numeric_limits<double>::max();
//                           Repaet NUM_RUNS times (5 times)
        for(i=0; i<NUM_RUNS;i++)
		{
			// create time variable
            double ArBBtime;
            {
				// start ArBB scoped timer which will measure
				// time within its scoped lifetime
                const arbb::scoped_timer timer(ArBBtime);
				// call main parallel track fitting function
				fitTracksArBB( T2, C2, nT, nS );
            }
			// scoped time ends here, var time holds its value
			// reset Timing to minimum time so far
            ArBBTiming = std::min(ArBBTiming, ArBBtime);
        }

// ------------------------- Verify results by comparing C and T final values
//                           between serial and parallel versions
        int errs = 0;

		for( unsigned int i = 0; i < nT; i ++ )
		{
            for( int j = 0; j < 15; j ++ )
			{
                if( fabs( C2[i][j] - C1[i][j] ) > DELTA )
				{
                    errs ++;
                    break;
                }
                if( j < 6 )
				{
                    if( fabs( T2[i][j] - T1[i][j] ) > DELTA )
					{
                        errs ++;
                        break;
                    }
                }
            }
        }

		printf( "===> Errors: %d/%d\n", errs, nT );

// ------------------------- Report serial and parallel timings and speedup
        printf( "--------------------------------------------------\n" );
        printf( "  Version          Minimum Time(s)       Speed Up\n" );
        printf( "  Serial         %12.6f\n", 0.001 * Timing );
        printf( "  ArBB parallel  %12.6f   %16.3f\n", 0.001 * ArBBTiming,
			                                           Timing/ArBBTiming );
        printf( "---------------------------------------------------\n" );

// ------------------------- Release space
        delete []T1;
        delete []C1;
        delete []T2;
        delete []C2;
//                           Finish message
        printf( "Test finished\n");
    }                        // end of try block
// ------------------------- Service Exception catches
	catch (const std::exception& e)
	{
        std::cerr << "Error: Caught unexpected std::exception." << std::endl;
        std::cerr << "\t"<< e.what() << std::endl;
        return EXIT_FAILURE;
    }
	catch (...)
	{
        std::cerr << "Error: Caught unexpected exception" << std::endl;
        std::cerr << "\t" << "<unknown-exception-type>" << std::endl;
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}

