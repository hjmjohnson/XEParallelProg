/**************************************************************************
 * CERN, GSI Darmstadt                                                    *
 * All rights reserved.                                                   *
 *                                                                        *
 * Permission to use, copy, modify and distribute this software and its   *
 * documentation strictly for non-commercial purposes is hereby granted   *
 * without fee, provided that the above copyright notice appears in all   *
 * copies and that both the copyright notice and this permission notice   *
 * appear in the supporting documentation. The authors make no claims     *
 * about the suitability of this software for any purpose. It is          *
 * provided "as is" without express or implied warranty.                  *
 **************************************************************************/

#include "fit_util.h"
#include "classes.h"
#include "arbb_classes.h"
#include "arbb.hpp"

using namespace arbb;

typedef f32 FTYPE;

typedef dense<array<FTYPE, 6> > vecTuple6Type;
typedef dense<array<FTYPE, 15> > vecTuple15Type;


#define MASS2 (FTYPE)(0.1396*0.1396)
#define CC1   (FTYPE)(  0.0136 )
#define CC2   (FTYPE)(  0.0136 * 0.038 )
#define CC3   (FTYPE)(  0.0136 * 0.038 * 0.5 )
#define CC4   (FTYPE)( -0.0136 * 0.038 * 0.5 / 2.0 )
#define CC5   (FTYPE)(  0.0136 * 0.038 * 0.5 / 3.0 )
#define CC6   (FTYPE)( -0.0136 * 0.038 * 0.5 / 4.0 )

#define _CLIGHT   ( 0.000299792458f )
#define _CLIGHT_I ( 1.f/0.000299792458f )

//extern FieldRegion  magField;
extern Stations     vStations;
extern Tracks       vTracks;


//namespace arbb_track_fitting2 {

template<typename U>
void guessVecArBB( TracksArBB<U> &ts, StationsArBB<U> &ss, dense<U> *T )
{
    //! Initialize parameters.
    U w = 1;   //h.w, seems that it's alway be 1, so here we use a const instead.
    U A0 = static_cast<typename uncaptured<U>::type>(vStations.nStations) * w;

    dense<U, 2> x = ts.hitsX;
    dense<U, 2> y = ts.hitsY;
    dense<U> z = ss.zhit - ss.zhit[vStations.nStations - 1];
    dense<U, 2> z2d = repeat_row( z, vTracks.nTracks );
    dense<U> S = ss.Sy;
    dense<U, 2> S2d = repeat_row( S, vTracks.nTracks );

    U A1 = add_reduce( z * w );
    U A2 = add_reduce( z * z * w );
    U A3 = add_reduce( S * w );
    U A4 = add_reduce( S * z * w );
    U A5 = add_reduce( S * S * w ); // optReduce of Vec now returns a Scalar
    dense<U> a0 = add_reduce( x * w );
    dense<U> a1 = add_reduce( x * z2d * w );
    dense<U> a2 = add_reduce( x * S2d * w );
    dense<U> b0 = add_reduce( y * w );
    dense<U> b1 = add_reduce( y * z2d * w );
    dense<U> b2 = add_reduce( y * S2d * w );

    U A3A3 = A3 * A3;
    U A3A4 = A3 * A4;
    U A1A5 = A1 * A5;
    U A2A5 = A2 * A5;
    U A4A4 = A4 * A4;

    U det = rcp( -A2 * A3A3 + A1 * ( A3A4 * 2 - A1A5 ) + A0 * ( A2A5 - A4A4 ) );
    U Ai0 = -A4A4 + A2A5;
    U Ai1 =  A3A4 - A1A5;
    U Ai2 = -A3A3 + A0 * A5;
    U Ai3 = -A2 * A3 + A1 * A4;
    U Ai4 =  A1 * A3 - A0 * A4;
    U Ai5 = -A1 * A1 + A0 * A2;

    T[0] = ( Ai0 * a0 + Ai1 * a1 + Ai3 * a2 ) * det;
    T[2] = ( Ai1 * a0 + Ai2 * a1 + Ai4 * a2 ) * det;

    dense<U> txtx1 = T[2] * T[2] + 1;

    dense<U> L = ( Ai3 * a0 + Ai4 * a1 + Ai5 * a2 ) * det * rcp ( txtx1 );
    dense<U> L1 = L * T[2];
    dense<U> A1V = A1 + A3 * L1;
    dense<U> A2V = A2 + ( A4 * (U)2 + A5 * L1 ) * L1;
    b1 += b2 * L1;
    dense<U> detV = rcp( -A1V * A1V + A0 * A2V );

    T[1] = (  A2V * b0 - A1V * b1 ) * detV;
    T[3] = ( -A1V * b0 + A0  * b1 ) * detV;
    T[4] = -L * _CLIGHT_I * rsqrt( txtx1 + T[3] * T[3] );
    T[5] = fill( (U)ss.zhit[vStations.nStations - 1], vTracks.nTracks );
}

template<typename U>
void filterFirstArBB( TracksArBB<U> &ts, StationsArBB<U> &ss, usize iStation,
                  dense<U> *T, dense<U> *C )
{
    //  CovV &C = track.C;
    U w = 1;
    U w1 = 1 - w;
    U sigma2 = w * ss.Sigma2[iStation] + w1 * INF;
    dense<U> _V0 = fill( (U)0, vTracks.nTracks );
    dense<U> sigV = fill( sigma2, vTracks.nTracks );
    dense<U> infV = fill( (U)INF, vTracks.nTracks );

    // initialize covariance matrix
    C[0] = sigV;                                                            //! C00
    C[1] = _V0;   C[2] = sigV;                                              //! C10, C11
    C[3] = _V0;   C[4] = _V0;   C[5] = infV;                                //! C20, C21, C22
    C[6] = _V0;   C[7] = _V0;   C[8] = _V0;   C[9] = infV;                  //! C30, C31, std::complex<f32> , C33
    C[10]= _V0;   C[11]= _V0;   C[12]= _V0;   C[13]= _V0;   C[14]= infV;    //! C40, C41, C42, C43, C44

    T[0] = w * ts.hitsX2.row( iStation ) + w1 * T[0];
    T[1] = w * ts.hitsY2.row( iStation ) + w1 * T[1];

    //! these two variables seem will never be used.
    //ftype NDF = -3.0;
    //ftype Chi2 = ZERO;
}

template<typename U>
void addMaterialArBB(TracksArBB<U>& /*ts*/, StationsArBB<U>& ss, usize iStation, dense<U>& qp0,
                 dense<U>* T, dense<U>* C)
{
    U mass2 = 0.1396 * 0.1396;

    dense<U> tx = T[2];
    dense<U> ty = T[3];
    dense<U> txtx = tx*tx;
    dense<U> tyty = ty*ty;
    dense<U> txtx1 = txtx + 1;
    dense<U> h = txtx + tyty;
    dense<U> t = sqrt(txtx1 + tyty);
    dense<U> h2 = h*h;
    dense<U> qp0t = qp0*t;

    dense<U> s0 = (CC1 + CC2 * ss.logRadThick[iStation] + CC3 * h + h2 * (CC4 + CC5 * h + CC6 * h2) ) * qp0t;

    dense<U> a = (MASS2 * qp0 * qp0t + 1) * ss.RadThick[iStation] * s0 * s0;

    C[5] += txtx1 * a;          //! C22
    C[8] += tx * ty * a;        //! std::complex<f32>
    C[9] += ( tyty + 1 ) * a;   //! C33
}

template<typename U>
void combineArBB( const dense<U> H[3], const U &w, dense<U> des[3] ){
    des[0] += w * (H[0] - des[0]);
    des[1] += w * (H[1] - des[1]);
    des[2] += w * (H[2] - des[2]);
}

template<typename U, typename W>
void extrapolateALightArBB2(
                       dense<U> *T, dense<U> *C,
                       const W &zOut,       // extrapolate to this z position
                       dense<U>& qp0,         // use Q/p linearisation at this value
                       FieldRegionArBB<U> &F)
{
    //
    //  Part of the analytic extrapolation formula with error (c_light*B*dz)^4/4!
    //
    dense<U> qp = T[4];
    dense<U> dz = (zOut - T[5]);
    dense<U> dz2 = dz * dz;
    dense<U> dz3 = dz2 * dz;

    // construct coefficients

    dense<U> x     = T[2]; // tx !!
    dense<U> y     = T[3]; // ty !!
    dense<U> xx    = x * x;
    dense<U> xy    = x * y;
    dense<U> yy    = y * y;
    dense<U> y2    = y * 2.0f;
    dense<U> x2    = x * 2.0f;
    dense<U> x4    = x * 4.0f;
    dense<U> xx31  = xx * 3.0f + 1.0f;
    dense<U> xx159 = xx * 15.0f + 9.0f;

    dense<U> Ay   = -xx - 1.0f;
    dense<U> Ayy  = x * ( xx * 3.0f + 3.0f );
    dense<U> Ayz  = -2.0f * xy;
    dense<U> Ayyy = -( 15.0f * xx * xx + 18.0f * xx + 3.0f);

    dense<U> Ayy_x  = 3.0f * xx31;
    dense<U> Ayyy_x = -x4 * xx159;

    dense<U> Bx = yy+1.0f;
    dense<U> Byy = y*xx31;
    dense<U> Byz = 2.0f*xx+1.0f;
    dense<U> Byyy = -xy*xx159;

    dense<U> Byy_x = 6.0f*xy;
    dense<U> Byyy_x = -y*(45.0f*xx+9.0f);
    dense<U> Byyy_y = -x*xx159;

    // end of coefficients calculation

    dense<U> t2   = 1.0f + xx + yy;
    dense<U> t    = sqrt( t2 );
    dense<U> h    = qp0*c_light;
    dense<U> ht   = h*t;

    // get field integrals
    dense<U> ddz = T[5] -F.z;
    dense<U> Fx0 = F.x0 + F.x1*ddz + F.x2*ddz*ddz;
    dense<U> Fx1 = (F.x1 + 2.0f*F.x2*ddz)*dz;
    dense<U> Fx2 = F.x2*dz2;
    dense<U> Fy0 = F.y0 + F.y1*ddz + F.y2*ddz*ddz;
    dense<U> Fy1 = (F.y1 + 2.0f*F.y2*ddz)*dz;
    dense<U> Fy2 = F.y2*dz2;
    dense<U> Fz0 = F.z0 + F.z1*ddz + F.z2*ddz*ddz;
    dense<U> Fz1 = (F.z1 + 2.0f*F.z2*ddz)*dz;
    dense<U> Fz2 = F.z2*dz2;

    //

    dense<U> sx = ( Fx0 + Fx1*( 1.0f / 2.0f ) + Fx2*( 1.0f / 3.0f ) );
    dense<U> sy = ( Fy0 + Fy1*( 1.0f / 2.0f ) + Fy2*( 1.0f / 3.0f ) );
    dense<U> sz = ( Fz0 + Fz1*( 1.0f / 2.0f ) + Fz2*( 1.0f / 3.0f ) );

    dense<U> Sx = ( Fx0*( 1.0f / 2.0f ) + Fx1*( 1.0f / 6.0f ) + Fx2*( 1.0f / 12.0f ) );
    dense<U> Sy = ( Fy0*( 1.0f / 2.0f ) + Fy1*( 1.0f / 6.0f ) + Fy2*( 1.0f / 12.0f ) );
    dense<U> Sz = ( Fz0*( 1.0f / 2.0f ) + Fz1*( 1.0f / 6.0f ) + Fz2*( 1.0f / 12.0f ) );

    dense<U> syz;
    {
        ftype _d = static_cast<ftype>(1./360.);
        U   d = _d,
            c00 = static_cast<ftype>(30.*6.*_d), c01 = static_cast<ftype>(30.*2.*_d),   c02 = static_cast<ftype>(30.*_d),
            c10 = static_cast<ftype>(3.*40.*_d), c11 = static_cast<ftype>(3.*15.*_d),   c12 = static_cast<ftype>(3.*8.*_d),
            c20 = static_cast<ftype>(2.*45.*_d), c21 = static_cast<ftype>(2.*2.*9.*_d), c22 = static_cast<ftype>(2.*2.*5.*_d);
        syz = Fy0*( c00*Fz0 + c01*Fz1 + c02*Fz2)
            +   Fy1*( c10*Fz0 + c11*Fz1 + c12*Fz2)
            +   Fy2*( c20*Fz0 + c21*Fz1 + c22*Fz2) ;
    }

    dense<U> Syz;
    {
        ftype _d = static_cast<ftype>(1./2520.);
        U   d = _d,
            c00 = static_cast<ftype>(21.*20.*_d), c01 = static_cast<ftype>(21.*5.*_d), c02 = static_cast<ftype>(21.*2.*_d),
            c10 =  static_cast<ftype>(7.*30.*_d), c11 =  static_cast<ftype>(7.*9.*_d), c12 =  static_cast<ftype>(7.*4.*_d),
            c20 =  static_cast<ftype>(2.*63.*_d), c21 = static_cast<ftype>(2.*21.*_d), c22 = static_cast<ftype>(2.*10.*_d);
        Syz = Fy0*( c00*Fz0 + c01*Fz1 + c02*Fz2 )
            +   Fy1*( c10*Fz0 + c11*Fz1 + c12*Fz2 )
            +   Fy2*( c20*Fz0 + c21*Fz1 + c22*Fz2 ) ;
    }

    dense<U> syy  = sy*sy*( 1.0f / 2.0f );
    dense<U> syyy = syy*sy*( 1.0f / 3.0f );

    dense<U> Syy ;
    {
        ftype _d = static_cast<ftype>(1./2520.);
        U   d= _d, c00= static_cast<ftype>(420.*_d), c01= static_cast<ftype>(21.*15.*_d), c02= static_cast<ftype>(21.*8.*_d),
            c03= static_cast<ftype>(63.*_d), c04= static_cast<ftype>(70.*_d), c05= static_cast<ftype>(20.*_d);
        Syy =  Fy0*(c00*Fy0+c01*Fy1+c02*Fy2) + Fy1*(c03*Fy1+c04*Fy2) + c05*Fy2*Fy2 ;
    }

    dense<U> Syyy;
    {
        ftype _d = static_cast<ftype>(1./181440.);
        U   d = _d,
            c000 =   7560*_d, c001 = 9*1008*_d, c002 = 5*1008*_d,
            c011 = 21*180*_d, c012 = 24*180*_d, c022 =  7*180*_d,
            c111 =    540*_d, c112 =    945*_d, c122 =    560*_d, c222 = 112*_d;
        dense<U> Fy22 = Fy2*Fy2;
        Syyy = Fy0*( Fy0*(c000*Fy0+c001*Fy1+c002*Fy2)+ Fy1*(c011*Fy1+c012*Fy2)+c022*Fy22 )
            +    Fy1*( Fy1*(c111*Fy1+c112*Fy2)+c122*Fy22) + c222*Fy22*Fy2                  ;
    }


    dense<U> sA1   = sx*xy   + sy*Ay   + sz*y ;
    dense<U> sA1_x = sx*y - sy*x2 ;
    dense<U> sA1_y = sx*x + sz ;

    dense<U> sB1   = sx*Bx   - sy*xy   - sz*x ;
    dense<U> sB1_x = -sy*y - sz ;
    dense<U> sB1_y = sx*y2 - sy*x ;

    dense<U> SA1   = Sx*xy   + Sy*Ay   + Sz*y ;
    dense<U> SA1_x = Sx*y - Sy*x2 ;
    dense<U> SA1_y = Sx*x + Sz;

    dense<U> SB1   = Sx*Bx   - Sy*xy   - Sz*x ;
    dense<U> SB1_x = -Sy*y - Sz;
    dense<U> SB1_y = Sx*y2 - Sy*x;


    dense<U> sA2   = syy*Ayy   + syz*Ayz ;
    dense<U> sA2_x = syy*Ayy_x - syz*y2 ;
    dense<U> sA2_y = -syz*x2 ;
    dense<U> sB2   = syy*Byy   + syz*Byz  ;
    dense<U> sB2_x = syy*Byy_x + syz*x4 ;
    dense<U> sB2_y = syy*xx31 ;

    dense<U> SA2   = Syy*Ayy   + Syz*Ayz ;
    dense<U> SA2_x = Syy*Ayy_x - Syz*y2 ;
    dense<U> SA2_y = -Syz*x2 ;
    dense<U> SB2   = Syy*Byy   + Syz*Byz ;
    dense<U> SB2_x = Syy*Byy_x + Syz*x4 ;
    dense<U> SB2_y = Syy*xx31 ;

    dense<U> sA3   = syyy*Ayyy  ;
    dense<U> sA3_x = syyy*Ayyy_x;
    dense<U> sB3   = syyy*Byyy  ;
    dense<U> sB3_x = syyy*Byyy_x;
    dense<U> sB3_y = syyy*Byyy_y;


    dense<U> SA3   = Syyy*Ayyy  ;
    dense<U> SA3_x = Syyy*Ayyy_x;
    dense<U> SB3   = Syyy*Byyy  ;
    dense<U> SB3_x = Syyy*Byyy_x;
    dense<U> SB3_y = Syyy*Byyy_y;

    dense<U> ht1 = ht*dz;
    dense<U> ht2 = ht*ht*dz2;
    dense<U> ht3 = ht*ht*ht*dz3;
    dense<U> ht1sA1 = ht1*sA1;
    dense<U> ht1sB1 = ht1*sB1;
    dense<U> ht1SA1 = ht1*SA1;
    dense<U> ht1SB1 = ht1*SB1;
    dense<U> ht2sA2 = ht2*sA2;
    dense<U> ht2SA2 = ht2*SA2;
    dense<U> ht2sB2 = ht2*sB2;
    dense<U> ht2SB2 = ht2*SB2;
    dense<U> ht3sA3 = ht3*sA3;
    dense<U> ht3sB3 = ht3*sB3;
    dense<U> ht3SA3 = ht3*SA3;
    dense<U> ht3SB3 = ht3*SB3;

    T[0] = T[0] + (x + ht1SA1 + ht2SA2 + ht3SA3)*dz ;
    T[1] = T[1] + (y + ht1SB1 + ht2SB2 + ht3SB3)*dz ;
    T[2] = T[2] + ht1sA1 + ht2sA2 + ht3sA3;
    T[3] = T[3] + ht1sB1 + ht2sB2 + ht3sB3;
    T[5]+= dz;

    dense<U> arbbdz  = c_light*t*dz;
    dense<U> arbbdz2 = c_light*t*dz2;

    dense<U> dqp = qp - qp0;
    dense<U> t2i = (U)1.0f*rcp(t2);// /t2;
    dense<U> xt2i = x*t2i;
    dense<U> yt2i = y*t2i;
    dense<U> tmp0 = ht1SA1 + 2.0f*ht2SA2 + 3.0f*ht3SA3;
    dense<U> tmp1 = ht1SB1 + 2.0f*ht2SB2 + 3.0f*ht3SB3;
    dense<U> tmp2 = ht1sA1 + 2.0f*ht2sA2 + 3.0f*ht3sA3;
    dense<U> tmp3 = ht1sB1 + 2.0f*ht2sB2 + 3.0f*ht3sB3;

    dense<U> j02 = dz*(1.0f + xt2i*tmp0 + ht1*SA1_x + ht2*SA2_x + ht3*SA3_x);
    dense<U> j12 = dz*(     xt2i*tmp1 + ht1*SB1_x + ht2*SB2_x + ht3*SB3_x);
    dense<U> j22 =     1.0f + xt2i*tmp2 + ht1*sA1_x + ht2*sA2_x + ht3*sA3_x ;
    dense<U> j32 =          xt2i*tmp3 + ht1*sB1_x + ht2*sB2_x + ht3*sB3_x ;

    dense<U> j03 = dz*(     yt2i*tmp0 + ht1*SA1_y + ht2*SA2_y );
    dense<U> j13 = dz*(1.0f + yt2i*tmp1 + ht1*SB1_y + ht2*SB2_y + ht3*SB3_y );
    dense<U> j23 =          yt2i*tmp2 + ht1*sA1_y + ht2*sA2_y  ;
    dense<U> j33 =     1.0f + yt2i*tmp3 + ht1*sB1_y + ht2*sB2_y + ht3*sB3_y ;

    dense<U> j04 = arbbdz2*( SA1 + 2.0f*ht1*SA2 + 3.0f*ht2*SA3 );
    dense<U> j14 = arbbdz2*( SB1 + 2.0f*ht1*SB2 + 3.0f*ht2*SB3 );
    dense<U> j24 = arbbdz *( sA1 + 2.0f*ht1*sA2 + 3.0f*ht2*sA3 );
    dense<U> j34 = arbbdz *( sB1 + 2.0f*ht1*sB2 + 3.0f*ht2*sB3 );

    // extrapolate inverse momentum

    T[0]+=j04*dqp;
    T[1]+=j14*dqp;
    T[2]+=j24*dqp;
    T[3]+=j34*dqp;

    //          covariance matrix transport

    dense<U> c42 = C[12], c43 = C[13];

    dense<U> cj00 = C[0] + C[3]*j02 + C[6]*j03 + C[10]*j04;
    dense<U> cj10 = C[1] + C[4]*j02 + C[7]*j03 + C[11]*j04;
    dense<U> cj20 = C[3] + C[5]*j02 + C[8]*j03 + C[12]*j04;
    dense<U> cj30 = C[6] + C[8]*j02 + C[9]*j03 + C[13]*j04;

    dense<U> cj01 = C[1] + C[3]*j12 + C[6]*j13 + C[10]*j14;
    dense<U> cj11 = C[2] + C[4]*j12 + C[7]*j13 + C[11]*j14;
    dense<U> cj21 = C[4] + C[5]*j12 + C[8]*j13 + c42*j14;
    dense<U> cj31 = C[7] + C[8]*j12 + C[9]*j13 + c43*j14;

    dense<U> cj02 = C[3]*j22 + C[6]*j23 + C[10]*j24;
    dense<U> cj12 = C[4]*j22 + C[7]*j23 + C[11]*j24;
    dense<U> cj22 = C[5]*j22 + C[8]*j23 + c42*j24;
    dense<U> cj32 = C[8]*j22 + C[9]*j23 + c43*j24;

    dense<U> cj03 = C[3]*j32 + C[6]*j33 + C[10]*j34;
    dense<U> cj13 = C[4]*j32 + C[7]*j33 + C[11]*j34;
    dense<U> cj23 = C[5]*j32 + C[8]*j33 + c42*j34;
    dense<U> cj33 = C[8]*j32 + C[9]*j33 + c43*j34;

    C[10]+= c42*j02 + c43*j03 + C[14]*j04; // cj40
    C[11]+= c42*j12 + c43*j13 + C[14]*j14; // cj41
    C[12] = c42*j22 + c43*j23 + C[14]*j24; // cj42
    C[13] = c42*j32 + c43*j33 + C[14]*j34; // cj43

    C[0] = cj00 + j02*cj20 + j03*cj30 + j04*C[10];
    C[1] = cj01 + j02*cj21 + j03*cj31 + j04*C[11];
    C[2] = cj11 + j12*cj21 + j13*cj31 + j14*C[11];

    C[3] = j22*cj20 + j23*cj30 + j24*C[10] ;
    C[6] = j32*cj20 + j33*cj30 + j34*C[10] ;
    C[4] = j22*cj21 + j23*cj31 + j24*C[11] ;
    C[7] = j32*cj21 + j33*cj31 + j34*C[11] ;
    C[5] = j22*cj22 + j23*cj32 + j24*C[12] ;
    C[8] = j32*cj22 + j33*cj32 + j34*C[12] ;
    C[9] = j32*cj23 + j33*cj33 + j34*C[13] ;
}


template<typename U>
void filterArBB(TracksArBB<U>& ts, StationsArBB<U>& /*ss*/, const U info[4], const dense<U>& u, const U& w,
            dense<U>* T, dense<U>* C)
{
    // convert input

    dense<U> zeta = info[0] * T[0] + info[1] * T[1] - u;
    // F = CH'
    dense<U> F0 = info[0] * C[0] + info[1] * C[1];
    dense<U> F1 = info[0] * C[1] + info[1] * C[2];

    dense<U> HCH = ( F0 * info[0] + F1 * info[1] );
    dense<i32> initialised = (dense<i32>)( HCH < info[3] );

    dense<U> F2 = info[0] * C[3]  + info[1] * C[4];
    dense<U> F3 = info[0] * C[6]  + info[1] * C[7];
    dense<U> F4 = info[0] * C[10] + info[1] * C[11];

    dense<U> wi = w * rcp( info[2] + HCH );
    dense<U> zetawi = w * zeta * rcp( dense<U>( initialised & (i32)info[2]) + HCH );
    dense<U> chi2 = (dense<U>)( initialised & (dense<i32>)(zeta * zetawi) );

    ts.NDF += (i32)w;

    dense<U> K1 = F1 * wi;
    dense<U> K2 = F2 * wi;
    dense<U> K3 = F3 * wi;
    dense<U> K4 = F4 * wi;

    T[0]-= F0*zetawi;
    T[1]-= F1*zetawi;
    T[2]-= F2*zetawi;
    T[3]-= F3*zetawi;
    T[4]-= F4*zetawi;

    C[0]-= F0*F0*wi;
    C[1]-= K1*F0;
    C[2]-= K1*F1;
    C[3]-= K2*F0;
    C[4]-= K2*F1;
    C[5]-= K2*F2;
    C[6]-= K3*F0;
    C[7]-= K3*F1;
    C[8]-= K3*F2;
    C[9]-= K3*F3;
    C[10]-= K4*F0;
    C[11]-= K4*F1;
    C[12]-= K4*F2;
    C[13]-= K4*F3;
    C[14]-= K4*F4;
}

//! main procedure of arbb track fitting
template<typename U>
void fitArBB2( TracksArBB<U> &ts, StationsArBB<U> &ss, FieldRegionArBB<U> &f,
            vecTuple6Type &vtT, vecTuple15Type &vtC)
{
    dense<U> T[6];
    dense<U> C[15];
#define GET(X, N) X[N] = vt##X.get<U, N>()
    GET(T, 0); GET(T, 1); GET(T, 2); GET(T, 3); GET(T, 4); GET(T, 5);
    GET(C, 0); GET(C, 1); GET(C, 2); GET(C, 3); GET(C, 4); GET(C, 5);
    GET(C, 6); GET(C, 7); GET(C, 8); GET(C, 9); GET(C, 10); GET(C, 11);
    GET(C, 11); GET(C, 12); GET(C, 13); GET(C, 14);
#undef GET

    // upstream
    guessVecArBB( ts, ss, T );

    U xInfo[4], yInfo[4];
    xInfo[0] = 1;                      //! cos_phi
    xInfo[1] = 0;                      //! sin_phi
    xInfo[2] = ss.Sigma2[0];            //! sigma2
    xInfo[3] = xInfo[2] * 16.0f;         //! sigma216

    yInfo[0] = 0;                      //! cos_phi
    yInfo[1] = 1;                      //! sin_phi
    yInfo[2] = xInfo[2];                //! sigma2
    yInfo[3] = xInfo[3];                //! sigma216

    // downstream
    //FieldRegionArBB<U> f;

    dense<U> qp0 = T[4];

    isize i = vStations.nStations - 1;

    filterFirstArBB( ts, ss, i, T, C );
    addMaterialArBB( ts, ss, i, qp0, T, C );

    U z1 = ss.z[i];
    dense<U> H0[3], H1[3], H2[3], HH[3];
    ss.field(i, T[0], T[1], H1);
    U w = 1.0f;   //h.w, since it's always 1.0.
    ss.field(i, ts.hitsX2.row( i ), ts.hitsY2.row( i ), HH);
    combineArBB<U>( HH, w, H1 );

    U z2 = ss.z[i - 2];
    U dz = z2-z1;
    ss.field( i - 2, T[0] + T[2] * dz, T[1] + T[3] * dz, H2);
    ss.field( i - 2, ts.hitsX2.row( i - 2 ), ts.hitsY2.row( i - 2), HH);
    combineArBB<U>( HH, w, H2 );

    _for( i -= 1, i >= 0, i-- ){
        U z0 = ss.z[i];
        dz = z1 - z0;
        ss.field( i, T[0] - T[2] * dz, T[1] - T[3] * dz, H0 );
        ss.field( i, ts.hitsX2.row( i ), ts.hitsY2.row( i ), HH );
        combineArBB<U>( HH, w, H0 );

        //! note: FieldRegionArBB f sets values here, needn't pass parameters
        f.set( H0, z0, H1, z1, H2, z2);

        extrapolateALightArBB2<U>( T, C, ss.zhit[i], qp0, f );
        addMaterialArBB( ts, ss, i, qp0, T, C );
        filterArBB( ts, ss, xInfo, ts.hitsX2.row( i ), w, T, C );
        filterArBB( ts, ss, yInfo, ts.hitsY2.row( i ), w, T, C );
        for( int j = 0; j < 3; j ++ ){
            H2[j] = H1[j];
            H1[j] = H0[j];
        }
        z2 = z1;
        z1 = z0;
    }_end_for;

    //! set to Tuples
#define SET(X, N) vt##X.set<N>(X[N])
    SET(T, 0); SET(T, 1); SET(T, 2); SET(T, 3); SET(T, 4); SET(T, 5);
    SET(C, 0); SET(C, 1); SET(C, 2); SET(C, 3); SET(C, 4); SET(C, 5);
    SET(C, 6); SET(C, 7); SET(C, 8); SET(C, 9); SET(C, 10); SET(C, 11);
    SET(C, 11); SET(C, 12); SET(C, 13); SET(C, 14);
#undef SET
}

void fitArBB( TracksArBB<FTYPE> &vTracksArBB, StationsArBB<FTYPE> &vStationsArBB,
			  FieldRegionArBB<FTYPE> &magFieldArBB,
            vecTuple6Type &vtT, vecTuple15Type &vtC)
{
        fitArBB2( vTracksArBB, vStationsArBB, magFieldArBB, vtT, vtC );
}

void extrapolateALightArBB( 
                       dense<FTYPE> *T, dense<FTYPE> *C,
                       dense<FTYPE> &value,       // extrapolate to this z position
                       dense<FTYPE>& value2,         // use Q/p linearisation at this value
                       FieldRegionArBB<FTYPE> &magFieldArBB)
{
 extrapolateALightArBB2<FTYPE>( T, C, value, value2, magFieldArBB );
}
