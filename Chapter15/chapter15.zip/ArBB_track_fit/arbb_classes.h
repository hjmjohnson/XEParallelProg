/**************************************************************************
 * CERN, GSI Darmstadt                                                    *
 * All rights reserved.                                                   *
 *                                                                        *
 * Permission to use, copy, modify and distribute this software and its   *
 * documentation strictly for non-commercial purposes is hereby granted   *
 * without fee, provided that the above copyright notice appears in all   *
 * copies and that both the copyright notice and this permission notice   *
 * appear in the supporting documentation. The authors make no claims     *
 * about the suitability of this software for any purpose. It is          *
 * provided "as is" without express or implied warranty.                  *
 **************************************************************************/

#include "fit_util.h"
#include "arbb.hpp"

#ifndef _ARBB_CLASSES
#define _ARBB_CLASSES

//namespace arbb_track_fitting2 {
using namespace arbb;

typedef f32 FTYPE;

//typedef dense<array<FTYPE, 6> > vecTuple6Type;
//typedef dense<array<FTYPE, 15> > vecTuple15Type;

template<typename T>
struct FieldRegionArBB{

    dense<T> x0, x1, x2 ; // Hx(Z) = x0 + x1*(Z-z) + x2*(Z-z)^2
    dense<T> y0, y1, y2 ; // Hy(Z) = y0 + y1*(Z-z) + y2*(Z-z)^2
    dense<T> z0, z1, z2 ; // Hz(Z) = z0 + z1*(Z-z) + z2*(Z-z)^2
    FTYPE z;

    FieldRegionArBB(usize nt)    {
        z = 0;
        x0 = x1 = x2 =
        y0 = y1 = y2 =
        z0 = z1 = z2 =
            fill(f32(0), nt);
    };

    void set( const dense<T> h0[3], const FTYPE &h0z,
              const dense<T> h1[3], const FTYPE &h1z,
              const dense<T> h2[3], const FTYPE &h2z){
            z = h0z;
            FTYPE dz1 = h1z-h0z, dz2 = h2z-h0z;
            FTYPE det = 1.0f/(dz1*dz2*(dz2-dz1));
            FTYPE w21 = -dz2*det;
            FTYPE w22 = dz1*det;
            FTYPE w11 = -dz2*w21;
            FTYPE w12 = -dz1*w22;

            dense<T> dh1 = h1[0] - h0[0];
            dense<T> dh2 = h2[0] - h0[0];
            x0 = h0[0];
            x1 = dh1*w11 + dh2*w12 ;
            x2 = dh1*w21 + dh2*w22 ;

            dh1 = h1[1] - h0[1];
            dh2 = h2[1] - h0[1];
            y0 = h0[1];
            y1 = dh1*w11 + dh2*w12 ;
            y2 = dh1*w21 + dh2*w22  ;

            dh1 = h1[2] - h0[2];
            dh2 = h2[2] - h0[2];
            z0 = h0[2];
            z1 = dh1*w11 + dh2*w12 ;
            z2 = dh1*w21 + dh2*w22 ;
    }

};

//! define stations (SOA)
template<typename U>
class StationsArBB{
public:

    dense<U> z, thick, zhit, RL,  RadThick, logRadThick, Sigma, Sigma2, Sy;
    dense<U, 2> mapX, mapY, mapZ; // polynomial coeff.

public:

    StationsArBB(){};
 

    void field( const usize &i, const dense<U> &x, const dense<U> &y, dense<U> H[3] ){
        dense<U> x2 = x*x;
        dense<U> y2 = y*y;
        dense<U> xy = x*y;
        dense<U> x3 = x2*x;
        dense<U> y3 = y2*y;
        dense<U> xy2 = x*y2;
        dense<U> x2y = x2*y;

        H[0] = mapX(0, i) +mapX(1, i)*x +mapX(2, i)*y +mapX(3, i)*x2 +mapX(4, i)*xy +mapX(5, i)*y2 +mapX(6, i)*x3 +mapX(7, i)*x2y +mapX(8, i)*xy2 +mapX(9, i)*y3;
        H[1] = mapY(0, i) +mapY(1, i)*x +mapY(2, i)*y +mapY(3, i)*x2 +mapY(4, i)*xy +mapY(5, i)*y2 +mapY(6, i)*x3 +mapY(7, i)*x2y +mapY(8, i)*xy2 +mapY(9, i)*y3;
        H[2] = mapZ(0, i) +mapZ(1, i)*x +mapZ(2, i)*y +mapZ(3, i)*x2 +mapZ(4, i)*xy +mapZ(5, i)*y2 +mapZ(6, i)*x3 +mapZ(7, i)*x2y +mapZ(8, i)*xy2 +mapZ(9, i)*y3;
    }
};

//! Define tracks (SOA)
template<typename T>
class TracksArBB
{
public:
    dense<T> MC_x, MC_y, MC_z, MC_px, MC_py, MC_pz, MC_q;
    dense<i32> nHits, NDF;
    dense<T, 2> hitsX, hitsY;
    dense<T, 2> hitsX2, hitsY2;
    dense<i32, 2> hitsIsta;

    TracksArBB(){};
    

};

  //void fitTracksArBB( ftype (*T)[6], ftype (*C)[15] );
//} // namespace arbb_track_fitting2

#endif 