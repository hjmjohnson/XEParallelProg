/**************************************************************************
 * CERN, GSI Darmstadt                                                    *
 * All rights reserved.                                                   *
 *                                                                        *
 * Permission to use, copy, modify and distribute this software and its   *
 * documentation strictly for non-commercial purposes is hereby granted   *
 * without fee, provided that the above copyright notice appears in all   *
 * copies and that both the copyright notice and this permission notice   *
 * appear in the supporting documentation. The authors make no claims     *
 * about the suitability of this software for any purpose. It is          *
 * provided "as is" without express or implied warranty.                  *
 **************************************************************************/

#include <iostream>  // for output messages
#include <limits>    // for data limits
#include "arbb.hpp"    // to access the ArBB libraries
#include "fit_util.h"    // a set of constants
#include "ittnotify.h""
#undef max      // undefine the max and min set up within windows
#undef min      // so that standard max and min can be used

typedef float ftype;    // set ftype to be single precision data

using namespace std;

// ------------------------- Protypes
void readInput( int * nT, int * nS);
void fitTracksArBB( ftype (*T)[6], ftype (*C)[15], int nT, int nS );

// ******************************************************************
int main(int argc, char* argv[])
{
    int i, nT, nS;  // loop conter, number of tracks & stations
	int num_threads = 0;
	double Timing;  // Timing value
	if(argc==2)
	{
		num_threads=atoi(argv[1]);
		arbb::num_threads(num_threads);
		printf("WARNING: Max threads set to: %d\n",num_threads);
	}
	
// -------------------------------------------------------------------
    try
	{
//                           Read dat from magnetic and track files
//                           Also sets up dynamic arrays whos pointers
//                           are loaded into the class pointer data
        readInput( &nT, &nS );
//                           Set up pointer arrays for parameters
//                           For each track set up array for State matrix
//                             T1[6] = x, y, tx, ty, qp, z
        ftype (*T1)[6]  = new ftype[nT][6];
//                            For each track set up array for Covariance matrix C1[15]
		ftype (*C1)[15] = new ftype[nT][15];

// ------------------------- Run Parallel ArBB version
		// Set Timing to maximum value for a double
        Timing = std::numeric_limits<double>::max();
		// Repaet NUM_RUNS times (5 times)

		__itt_domain* pD = __itt_domain_create( "TrackFitter" );
		pD->flags = 1; /* enable domain */


        for(i=0; i<NUM_RUNS;i++)
		{
			// create time variable
            double time;
            {
				// start ArBB scoped timer which will measure
				// time within its scoped lifetime
				// start a frame for vtune
				__itt_frame_begin_v3(pD, NULL);
				const arbb::scoped_timer timer(time);
				// call main parallel track fitting function
				fitTracksArBB( T1, C1, nT, nS );
            }
			// scoped time ends here, var time holds its value
			// reset Timing to minimum time so far
            Timing = std::min(Timing, time);
			__itt_frame_end_v3(pD, NULL);

        }


// ------------------------- Report Parallel timing
        printf( "----------------------------------------\n" );
        printf( "  Version          Minimum Time(s)\n" );
        printf( "  ArBB parallel  %12.6f\n", 0.001 * Timing );
        printf( "----------------------------------------\n" );

//                           release space
        delete []T1;
        delete []C1;
//                           Finish message
        printf( "Test finished\n");
    }                        // end of try block
// ------------------------- Service Exception catches
	catch (const std::exception& e)
	{
        std::cerr << "Error: Caught unexpected std::exception." << std::endl;
        std::cerr << "\t"<< e.what() << std::endl;
        return EXIT_FAILURE;
    }
	catch (...)
	{
        std::cerr << "Error: Caught unexpected exception" << std::endl;
        std::cerr << "\t" << "<unknown-exception-type>" << std::endl;
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}

