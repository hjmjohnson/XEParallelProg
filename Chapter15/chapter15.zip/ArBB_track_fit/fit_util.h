/**************************************************************************
 * CERN, GSI Darmstadt                                                    *
 * All rights reserved.                                                   *
 *                                                                        *
 * Permission to use, copy, modify and distribute this software and its   *
 * documentation strictly for non-commercial purposes is hereby granted   *
 * without fee, provided that the above copyright notice appears in all   *
 * copies and that both the copyright notice and this permission notice   *
 * appear in the supporting documentation. The authors make no claims     *
 * about the suitability of this software for any purpose. It is          *
 * provided "as is" without express or implied warranty.                  *
 **************************************************************************/

#ifndef _UTIL
#define _UTIL
//static const int maxNStations = 8;
static const int maxNStations = 24;
static const int maxNTracks = 20000;
static const int Ntimes = 100;
#define NUM_RUNS 5

#define INF 0.01
#define ZERO 0.0
#define ONE 1.
#define c_light 0.000299792458
#define c_light_i 1./c_light

#endif