/**************************************************************************
 * CERN, GSI Darmstadt                                                    *
 * All rights reserved.                                                   *
 *                                                                        *
 * Permission to use, copy, modify and distribute this software and its   *
 * documentation strictly for non-commercial purposes is hereby granted   *
 * without fee, provided that the above copyright notice appears in all   *
 * copies and that both the copyright notice and this permission notice   *
 * appear in the supporting documentation. The authors make no claims     *
 * about the suitability of this software for any purpose. It is          *
 * provided "as is" without express or implied warranty.                  *
 **************************************************************************/

#include <iostream>
#include <fstream>
#include <math.h>
#include "fit_util.h"
#include "classes.h"       // Main Kalman Filter classes

typedef float ftype;

using namespace std;

// ------------------------- Global data, instances of classes
FieldRegion     magField;
Stations        vStations;
Tracks          vTracks;


void readInput( int * pnt, int * pns )
{
	*pnt = 0;
	*pns = 0;
    fstream FileGeo, FileTracks;

    FileGeo.open( "geo.dat", std::ios::in );
    if ( ! FileGeo.is_open() )
        cout<<"Open geo.dat fails"<<endl;
    FileTracks.open( "tracks.dat", std::ios::in );
    if ( ! FileTracks.is_open() )
        cout<<"Open track.dat fails"<<endl;
    {
        ftype H[3][3];
        ftype Hz[3];
        for( int i=0; i<3; i++){
            ftype Bx, By, Bz, z;
            FileGeo >> z >> Bx >> By >> Bz;
            Hz[i] = z; H[i][0] = Bx;   H[i][1] = By; H[i][2] = Bz;
            cout<<"Input Magnetic field:"<<z<<" "<<Bx<<" "<<By<<" "<<Bz<<endl;
        }
        magField.set( H[0], Hz[0], H[1], Hz[1], H[2], Hz[2] );
    }
    int nStations;
    FileGeo >> nStations;
    cout<<"Input "<<nStations<<" Stations:"<<endl;
    vStations.init( nStations );
    for( int i=0; i<nStations; i++ ){
        int ist;
        FileGeo >> ist;
        if( ist!=i ) break;
        FileGeo >> vStations.z[i] >> vStations.thick[i]>> vStations.RL[i];
        cout<<"    "<<vStations.z[i] <<" "<<vStations.thick[i]<<" "<<vStations.RL[i]<<", ";
        vStations.zhit[i] = vStations.z[i] - vStations.thick[i]/2.f;
        vStations.RadThick[i] = vStations.thick[i]/vStations.RL[i];
        vStations.logRadThick[i] = log(vStations.RadThick[i]);
        int N=0;
        FileGeo >> N;
        cout<<N<<" field coeff."<<endl;
        ftype mx[10], my[10], mz[10];
        for( int j=0; j<N; j++ ) FileGeo >> mx[j];
        for( int j=0; j<N; j++ ) FileGeo >> my[j];
        for( int j=0; j<N; j++ ) FileGeo >> mz[j];
        vStations.initMap( i, mx, my, mz );
    }
    {
        ftype z0  = vStations.z[nStations-1];
        ftype sy = 0., Sy = 0.;
        for( int i=nStations-1; i>=0; i-- ){
            ftype dz = vStations.z[i]-z0;
            ftype Hy = vStations.mapY[i][0];
            Sy += dz*sy + dz*dz*Hy/2.f;
            sy += dz*Hy;
            vStations.Sy[i] = Sy;
            z0 = vStations.z[i];
        }
    }

    FileGeo.close();

    cout << "Number of stations = " << nStations << endl;

    vTracks.init( nStations, maxNTracks );
    int nTracks = 0;

    while( !FileTracks.eof() ){

        int itr;
        FileTracks>>itr;
        //if( itr!=nTracks ) break;
        if( nTracks>=maxNTracks ) break;

        ftype MC_para[7];
        int lNHits = 0;
        FileTracks >> MC_para[0] >> MC_para[1] >> MC_para[2]
        >> MC_para[3] >> MC_para[4] >> MC_para[5] >> MC_para[6]
        >> lNHits;
        int *lIsta = (int*)malloc(lNHits*sizeof(int));
        ftype *lHitsX = (ftype*)malloc(lNHits*sizeof(ftype));
        ftype *lHitsY = (ftype*)malloc(lNHits*sizeof(ftype));
        for( int i=0; i<lNHits; i++ ){
            FileTracks >> lIsta[i];
            FileTracks >> lHitsX[i] >> lHitsY[i];
        }
        if( lNHits == nStations ){
            vTracks.setMC( nTracks, MC_para );
            vTracks.setHits( nTracks, lIsta, lHitsX, lHitsY );
            nTracks++;
        }
        free( lIsta );
        free( lHitsX );
        free( lHitsY );
    }
    vTracks.nTracks = nTracks;

    FileTracks.close();

    cout << "Number of tracks = " << nTracks << endl;
	*pnt = nTracks;
	*pns = nStations;
}

