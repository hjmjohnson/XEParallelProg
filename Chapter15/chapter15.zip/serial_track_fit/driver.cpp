/**************************************************************************
 * CERN, GSI Darmstadt                                                    *
 * All rights reserved.                                                   *
 *                                                                        *
 * Permission to use, copy, modify and distribute this software and its   *
 * documentation strictly for non-commercial purposes is hereby granted   *
 * without fee, provided that the above copyright notice appears in all   *
 * copies and that both the copyright notice and this permission notice   *
 * appear in the supporting documentation. The authors make no claims     *
 * about the suitability of this software for any purpose. It is          *
 * provided "as is" without express or implied warranty.                  *
 **************************************************************************/
#include <math.h>
#include "fit_util.h"      // set of constants
#include "classes.h"       // Main Kalman Filter classes

typedef float ftype;  // set ftype to be single precision data

using namespace std;

extern FieldRegion  magField;
extern Stations     vStations;
extern Tracks       vTracks;

// ------------------------- Prototypes
void fit( int iTrack, ftype T[6], ftype C[15] );
void extrapolateALight( ftype T[], ftype C[], const ftype zOut, ftype qp0,
					    FieldRegion &F );

// ********** Driver of Serial Version of Kalman Filter *********
void fitTracks( ftype (*T)[6], ftype (*C)[15], int nT, int nS )
{
//                           Repeat the Kalman filtering 100 times
    for( int times=0; times<Ntimes; times++)
	{
//                           take each track in turn and process
        for( unsigned int i=0; i<nT; i++ )
		{
//                           apply Kalman Filter to track
            fit( i, T[i], C[i] );
        }
    }
//                           extrapolate all tracks back to start
    for( unsigned int i=0; i<nT; i++ )
	{
        extrapolateALight( T[i], C[i], vTracks.MC_z[i], T[i][4], magField );
    }
}

