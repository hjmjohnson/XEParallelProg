/**************************************************************************
 * CERN, GSI Darmstadt                                                    *
 * All rights reserved.                                                   *
 *                                                                        *
 * Permission to use, copy, modify and distribute this software and its   *
 * documentation strictly for non-commercial purposes is hereby granted   *
 * without fee, provided that the above copyright notice appears in all   *
 * copies and that both the copyright notice and this permission notice   *
 * appear in the supporting documentation. The authors make no claims     *
 * about the suitability of this software for any purpose. It is          *
 * provided "as is" without express or implied warranty.                  *
 **************************************************************************/

//typedef float ftype;
#include <stdlib.h>
#include "fit_util.h"
#include <cstring>

typedef float ftype;

#ifndef _CLASSES
#define _CLASSES

//! Define the magnetic field
class FieldRegion{
public:
//struct FieldRegion{
    ftype x0, x1, x2 ; // Hx(Z) = x0 + x1*(Z-z) + x2*(Z-z)^2
    ftype y0, y1, y2 ; // Hy(Z) = y0 + y1*(Z-z) + y2*(Z-z)^2
    ftype z0, z1, z2 ; // Hz(Z) = z0 + z1*(Z-z) + z2*(Z-z)^2
    ftype z;

    FieldRegion(){
        x0 = x1 = x2 = y0 = y1 = y2 = z0 = z1 = z2 = z = 0.;
    }

    void set( const ftype h0[3], const ftype &h0z,
              const ftype h1[3], const ftype &h1z,
              const ftype h2[3], const ftype &h2z){
            z = h0z;
            ftype dz1 = h1z-h0z, dz2 = h2z-h0z;
            ftype det = 1.0f/(dz1*dz2*(dz2-dz1));
            ftype w21 = -dz2*det;
            ftype w22 = dz1*det;
            ftype w11 = -dz2*w21;
            ftype w12 = -dz1*w22;

            ftype dh1 = h1[0] - h0[0];
            ftype dh2 = h2[0] - h0[0];
            x0 = h0[0];
            x1 = dh1*w11 + dh2*w12 ;
            x2 = dh1*w21 + dh2*w22 ;

            dh1 = h1[1] - h0[1];
            dh2 = h2[1] - h0[1];
            y0 = h0[1];
            y1 = dh1*w11 + dh2*w12 ;
            y2 = dh1*w21 + dh2*w22  ;

            dh1 = h1[2] - h0[2];
            dh2 = h2[2] - h0[2];
            z0 = h0[2];
            z1 = dh1*w11 + dh2*w12 ;
            z2 = dh1*w21 + dh2*w22 ;
    }

 };


//! Define stations (tracking detector) (SOA)
class Stations{
public:
//struct Stations{
    int nStations;

    ftype *z, *thick, *zhit, *RL,  *RadThick, *logRadThick, *Sigma, *Sigma2, *Sy;
    ftype (**mapX), (**mapY), (**mapZ); // polinom coeff.

    void initMap( int i, ftype *x, ftype *y, ftype *z ){
        memcpy( mapX[i], x, sizeof( ftype ) * 10 );
        memcpy( mapY[i], y, sizeof( ftype ) * 10 );
        memcpy( mapZ[i], z, sizeof( ftype ) * 10 );
    }

    //Stations();
    //Stations( int ns );

    //void init( int ns );

    //~Stations();

    void field( int i, const ftype x, const ftype y, ftype H[3] ){
        ftype x2 = x*x;
        ftype y2 = y*y;
        ftype xy = x*y;
        ftype x3 = x2*x;
        ftype y3 = y2*y;
        ftype xy2 = x*y2;
        ftype x2y = x2*y;

        H[0] = mapX[i][0] +mapX[i][1]*x +mapX[i][2]*y +mapX[i][3]*x2 +mapX[i][4]*xy +mapX[i][5]*y2 +mapX[i][6]*x3 +mapX[i][7]*x2y +mapX[i][8]*xy2 +mapX[i][9]*y3;
        H[1] = mapY[i][0] +mapY[i][1]*x +mapY[i][2]*y +mapY[i][3]*x2 +mapY[i][4]*xy +mapY[i][5]*y2 +mapY[i][6]*x3 +mapY[i][7]*x2y +mapY[i][8]*xy2 +mapY[i][9]*y3;
        H[2] = mapZ[i][0] +mapZ[i][1]*x +mapZ[i][2]*y +mapZ[i][3]*x2 +mapZ[i][4]*xy +mapZ[i][5]*y2 +mapZ[i][6]*x3 +mapZ[i][7]*x2y +mapZ[i][8]*xy2 +mapZ[i][9]*y3;
    }

    Stations()
    : nStations(0), z(NULL), thick(NULL), zhit(NULL), RL(NULL), RadThick(NULL), logRadThick(NULL),
      Sigma(NULL), Sigma2(NULL), Sy(NULL), mapX(NULL), mapY(NULL), mapZ(NULL)
    {}


    Stations( int ns )
    {
        init( ns );
    }


    void init( int ns )
    {
        nStations = ns;

        z = (ftype*)malloc(ns*sizeof(ftype));
        thick = (ftype*)malloc(ns*sizeof(ftype));
        zhit = (ftype*)malloc(ns*sizeof(ftype));
        RL = (ftype*)malloc(ns*sizeof(ftype));
        RadThick = (ftype*)malloc(ns*sizeof(ftype));
        logRadThick = (ftype*)malloc(ns*sizeof(ftype));
        Sigma = (ftype*)malloc(ns*sizeof(ftype));
        Sigma2 = (ftype*)malloc(ns*sizeof(ftype));
        Sy = (ftype*)malloc(ns*sizeof(ftype));

        mapX = (ftype**)malloc(ns*sizeof(ftype*));
        mapY = (ftype**)malloc(ns*sizeof(ftype*));
        mapZ = (ftype**)malloc(ns*sizeof(ftype*));

        mapXPool = (ftype*) malloc( sizeof( ftype ) * ns * 10 );
        mapYPool = (ftype*) malloc( sizeof( ftype ) * ns * 10 );
        mapZPool = (ftype*) malloc( sizeof( ftype ) * ns * 10 );

        for( int i = 0; i < ns; i ++ ){
            mapX[i] = mapXPool + i * 10;
            mapY[i] = mapYPool + i * 10;
            mapZ[i] = mapZPool + i * 10;
        }

        for( int i = 0; i < ns; i ++ ){
            Sigma[i] = 20.E-4f;
            Sigma2[i] = Sigma[i] * Sigma[i];
        }
    }

    ~Stations()
    {
        if( z ) free(z);
        if( thick ) free(thick);
        if( zhit ) free(zhit);
        if( RL ) free(RL);
        if( RadThick ) free(RadThick);
        if( logRadThick ) free(logRadThick);
        if( Sigma ) free(Sigma);
        if( Sigma2 ) free(Sigma2);
        if( Sy ) free(Sy);

        if( mapX ) free(mapX);
        if( mapY ) free(mapY);
        if( mapZ ) free(mapZ);

        if( mapXPool ) free(mapXPool);
        if( mapYPool ) free(mapYPool);
        if( mapZPool ) free(mapZPool);
    }

private:
    ftype *mapXPool, *mapYPool, *mapZPool;  //! to make the mem address contineous (for arbb copyin)
};


//! Define tracks (SOA)
class Tracks
{
public:
    //Tracks();
    //void init( int ns, int nt );
    //~Tracks();

    //void setMC( int i, ftype * MC_para );
    //void setHits( int i, int *iSta, ftype *hitsX, ftype *hitsY );

//private:
    unsigned int nStations;
    unsigned int nTracks;

    ftype *MC_x, *MC_y, *MC_z, *MC_px, *MC_py, *MC_pz, *MC_q;
//    ftype (*T)[6];    //for each track, T[6] = x, y, tx, ty, qp, z
//    ftype (*C)[15];   //for each track, C[15] is the covariance matrix

    int *nHits, *NDF;
    ftype **hitsX, **hitsY;
    ftype *hitsX2, *hitsY2;
    int **hitsIsta;

	Tracks()
    {
        MC_x = MC_y = MC_z = MC_px = MC_py = MC_pz = MC_q = NULL;
        nHits = NDF = NULL;
        hitsX = NULL;
        hitsY = NULL;
        hitsIsta = NULL;
 //       T = NULL;
 //       C = NULL;
    }


    void init( int ns, int nt )
    {
        nTracks = nt;
        MC_x = ( ftype* ) malloc( sizeof( ftype ) * nt );
        MC_y = ( ftype* ) malloc( sizeof( ftype ) * nt );
        MC_z = ( ftype* ) malloc( sizeof( ftype ) * nt );
        MC_px = ( ftype* ) malloc( sizeof( ftype ) * nt );
        MC_py = ( ftype* ) malloc( sizeof( ftype ) * nt );
        MC_pz = ( ftype* ) malloc( sizeof( ftype ) * nt );
        MC_q = ( ftype* ) malloc( sizeof( ftype ) * nt );
        nHits = ( int* ) malloc( sizeof( int ) * nt );
        NDF = ( int* ) malloc( sizeof( int ) * nt );

        nStations = ns;

        memXPool = ( ftype* ) malloc( sizeof( ftype ) * nt * nStations );
        memYPool = ( ftype* ) malloc( sizeof( ftype ) * nt * nStations );
        memIstaPool = ( int* ) malloc( sizeof( int ) * nt * nStations );

        hitsX = ( ftype ** ) malloc( sizeof( ftype * ) * nt );
        hitsY = ( ftype ** ) malloc( sizeof( ftype * ) * nt );
        hitsIsta = ( int ** ) malloc( sizeof( int * ) * nt );

        for( int i = 0; i < nt; i ++ ){
            hitsX[i] = ( ftype* )( memXPool + i * ns );
            hitsY[i] = ( ftype* )( memYPool + i * ns );
            hitsIsta[i] = ( int* )( memIstaPool + i * ns );
        }

        hitsX2 = ( ftype* ) malloc( sizeof( ftype ) * nStations * nt  );
        hitsY2 = ( ftype* ) malloc( sizeof( ftype ) * nStations * nt  );

 //       T = new ftype[vTracks.nTracks][6];
 //       C = new ftype[vTracks.nTracks][15];
    }


    ~Tracks()
    {
    //if( MC_x != NULL ) free( MC_x );
    //if( MC_y != NULL ) free( MC_y );
    //if( MC_z != NULL ) free( MC_z );
    //if( MC_px != NULL ) free( MC_px );
    //if( MC_py != NULL ) free( MC_py );
    //if( MC_pz != NULL ) free( MC_pz );
    //if( MC_q != NULL ) free( MC_q );
    //if( nHits != NULL ) free( nHits );
    //if( NDF != NULL ) free( NDF );

    //if( memXPool != NULL ) free( memXPool );
    //if( memYPool != NULL ) free( memYPool );
    //if( memIstaPool != NULL ) free( memIstaPool );
    //
    //if( hitsX != NULL ) free( hitsX );
    //if( hitsY != NULL ) free( hitsY );
    //if( hitsIsta != NULL ) free( hitsIsta );

 //   if( T != NULL ) delete T;
 //   if( C != NULL ) delete C;
    }


    void setMC( int i, ftype *MC_para )
    {
        MC_x[i] = MC_para[0];
        MC_y[i] = MC_para[1];
        MC_z[i] = MC_para[2];
        MC_px[i] = MC_para[3];
        MC_py[i] = MC_para[4];
        MC_pz[i] = MC_para[5];
        MC_q[i] = MC_para[6];
     }


    void setHits( int i, int *iSta, ftype *hx, ftype *hy )
    {
        for( unsigned int j = 0; j < nStations; j ++ ){
            hitsX[i][j] = hx[j];
            hitsY[i][j] = hy[j];
            hitsIsta[i][j] = iSta[j];
        }
    }

private:
    //! define three pool for hitsX, hitsY and hitsIsta to make the memory location is continueous.
    ftype *memXPool, *memYPool;
    int *memIstaPool;
};


#endif 
